# Import required modules
import random
import time

# Selection Sort function
def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i+1, n):
            if arr[min_idx] > arr[j]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

# Bubble Sort function
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1] :
                arr[j], arr[j+1] = arr[j+1], arr[j]

# Merge Sort function
def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr)//2
        L = arr[:mid]
        R = arr[mid:]
 
        merge_sort(L)
        merge_sort(R)
 
        i = j = k = 0
 
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
 
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
 
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1

# Quick Sort function
def quick_sort(arr, low, high):
    if low < high:
        pi = partition(arr,low,high)
 
        quick_sort(arr, low, pi-1)
        quick_sort(arr, pi+1, high)
 
def partition(arr, low, high):
    i = ( low-1 )
    pivot = arr[high]
 
    for j in range(low , high):
        if arr[j] <= pivot:
            i = i+1
            arr[i],arr[j] = arr[j],arr[i]
 
    arr[i+1],arr[high] = arr[high],arr[i+1]
    return ( i+1 )

# Main Program
if __name__ == '__main__':

    sizes = [50000, 100000, 150000, 200000, 250000, 300000]  # Input sizes
    sort_functions = [selection_sort, bubble_sort, merge_sort, quick_sort]  # Sort functions
    
    # Create a table to store execution times for each sort and input size
    execution_times = []
    for _ in range(len(sort_functions)):
        execution_times.append([0]*len(sizes))
    
    # Loop through each input size
    for i, n in enumerate(sizes):
        arr = [random.randint(0,10000) for _ in range(n)]  # Generate input array of size n
        
        # Loop through each sort function
        for j, sort_func in enumerate(sort_functions):
            arr_copy = arr.copy()  # Make a copy of the input array to avoid modifying it
            start_time = time.time()  # Start time
            
            # For Quick Sort function, call it with low and high arguments
            if sort_func == quick_sort:
                sort_func(arr_copy, 0, len(arr_copy)-1)
            else:
                sort_func(arr_copy)
                
            end_time = time.time()  # End time
            elapsed_time = end_time - start_time  # Calculate elapsed time
            execution_times[j][i] = elapsed_time  # Store elapsed time in table
    
    # Print the table    
    print("| {:<15} | {:<15} | {:<15} | {:<15} | {:<15} | {:<15} |".format("Input Size","Selection Sort","Bubble Sort","Merge Sort","Quick Sort",""))
    print("|{}|".format("-"*81))
    for i in range(len(sizes)):
        row = "| {:<15} |".format(sizes[i])
        for j in range(len(sort_functions)):
            row += " {:<15.6f} |".format(execution_times[j][i])
        row += " {:<15} |".format("")
        print(row)